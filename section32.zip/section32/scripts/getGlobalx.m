function r = getGlobalx
x = 'kernel';
r = x;