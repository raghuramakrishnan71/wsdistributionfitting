function[STT] = GenerateSTTUsingBurr(inpath, noOfSimulations, outpath, outfilename)

X3_1= ReadDataFromFile2(inpath, '11.csv');
X3_2= ReadDataFromFile2(inpath, '12.csv');
X3_3= ReadDataFromFile2(inpath, '13.csv');
X3_4= ReadDataFromFile2(inpath, '14.csv');
X3_5= ReadDataFromFile2(inpath, '15.csv');
X3 = [X3_1; X3_2; X3_3; X3_4; X3_5];

X4_1= ReadDataFromFile2(inpath, '16.csv');
X4_2= ReadDataFromFile2(inpath, '17.csv');
X4_3= ReadDataFromFile2(inpath, '18.csv');
X4_4= ReadDataFromFile2(inpath, '19.csv');
X4_5= ReadDataFromFile2(inpath, '20.csv');
X4 = [X4_1; X4_2; X4_3; X4_4; X4_5];

X5_1= ReadDataFromFile2(inpath, '21.csv');
X5_2= ReadDataFromFile2(inpath, '22.csv');
X5_3= ReadDataFromFile2(inpath, '23.csv');
X5_4= ReadDataFromFile2(inpath, '24.csv');
X5_5= ReadDataFromFile2(inpath, '25.csv');
X5 = [X5_1; X5_2; X5_3; X5_4; X5_5];

X6_1= ReadDataFromFile2(inpath, '26.csv');
X6_2= ReadDataFromFile2(inpath, '27.csv');
X6_3= ReadDataFromFile2(inpath, '28.csv');
X6_4= ReadDataFromFile2(inpath, '29.csv');
X6_5= ReadDataFromFile2(inpath, '30.csv');
X6 = [X6_1; X6_2; X6_3; X6_4; X6_5];

X7_1= ReadDataFromFile2(inpath, '31.csv');
X7_2= ReadDataFromFile2(inpath, '32.csv');
X7_3= ReadDataFromFile2(inpath, '33.csv');
X7_4= ReadDataFromFile2(inpath, '34.csv');
X7_5= ReadDataFromFile2(inpath, '35.csv');
X7 = [X7_1; X7_2; X7_3; X7_4; X7_5];

X8_1= ReadDataFromFile2(inpath, '36.csv');
X8_2= ReadDataFromFile2(inpath, '37.csv');
X8_3= ReadDataFromFile2(inpath, '38.csv');
X8_4= ReadDataFromFile2(inpath, '39.csv');
X8_5= ReadDataFromFile2(inpath, '40.csv');
X8 = [X8_1; X8_2; X8_3; X8_4; X8_5];

X10_1= ReadDataFromFile2(inpath, '46.csv');
X10_2= ReadDataFromFile2(inpath, '47.csv');
X10_3= ReadDataFromFile2(inpath, '48.csv');
X10_4= ReadDataFromFile2(inpath, '49.csv');
X10_5= ReadDataFromFile2(inpath, '50.csv');
X10 = [X10_1; X10_2; X10_3; X10_4; X10_5];

X11_1= ReadDataFromFile2(inpath, '51.csv');
X11_2= ReadDataFromFile2(inpath, '52.csv');
X11_3= ReadDataFromFile2(inpath, '53.csv');
X11_4= ReadDataFromFile2(inpath, '54.csv');
X11_5= ReadDataFromFile2(inpath, '55.csv');
X11 = [X11_1; X11_2; X11_3; X11_4; X11_5];

X12_1= ReadDataFromFile2(inpath, '56.csv');
X12_2= ReadDataFromFile2(inpath, '57.csv');
X12_3= ReadDataFromFile2(inpath, '58.csv');
X12_4= ReadDataFromFile2(inpath, '59.csv');
X12_5= ReadDataFromFile2(inpath, '60.csv');
X12 = [X12_1; X12_2; X12_3; X12_4; X12_5];

X13_1= ReadDataFromFile2(inpath, '61.csv');
X13_2= ReadDataFromFile2(inpath, '62.csv');
X13_3= ReadDataFromFile2(inpath, '63.csv');
X13_4= ReadDataFromFile2(inpath, '64.csv');
X13_5= ReadDataFromFile2(inpath, '65.csv');
X13 = [X13_1; X13_2; X13_3; X13_4; X13_5];

X14_1= ReadDataFromFile2(inpath, '66.csv');
X14_2= ReadDataFromFile2(inpath, '67.csv');
X14_3= ReadDataFromFile2(inpath, '68.csv');
X14_4= ReadDataFromFile2(inpath, '69.csv');
X14_5= ReadDataFromFile2(inpath, '70.csv');
X14 = [X14_1; X14_2; X14_3; X14_4; X14_5];

X15_1= ReadDataFromFile2(inpath, '71.csv');
X15_2= ReadDataFromFile2(inpath, '72.csv');
X15_3= ReadDataFromFile2(inpath, '73.csv');
X15_4= ReadDataFromFile2(inpath, '74.csv');
X15_5= ReadDataFromFile2(inpath, '75.csv');
X15 = [X15_1; X15_2; X15_3; X15_4; X15_5];

X16_1= ReadDataFromFile2(inpath, '76.csv');
X16_2= ReadDataFromFile2(inpath, '77.csv');
X16_3= ReadDataFromFile2(inpath, '78.csv');
X16_4= ReadDataFromFile2(inpath, '79.csv');
X16_5= ReadDataFromFile2(inpath, '80.csv');
X16 = [X16_1; X16_2; X16_3; X16_4; X16_5];

fprintf('Distribution|hvalue|pvalue|kststat|cv|samplesize|mean|median|90|99|mean|median|90|99|\n');

pd3 = fitdist(X3, 'Burr');
[HVALUE,PVALUE,ksstat,cv] = kstest(X3, 'CDF', pd3);
fprintf('Burr|%d|%0.3f|%0.3f|%0.3f|%d|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f\n', HVALUE, PVALUE, ksstat, cv, length(X3), mean(X3), median(X3), prctile(X3, 90), prctile(X3, 99), mean(pd3), median(pd3), icdf(pd3, 0.90), icdf(pd3, 0.99));

pd4 = fitdist(X4, 'Burr');
[HVALUE,PVALUE,ksstat,cv] = kstest(X4, 'CDF', pd4);
fprintf('Burr|%d|%0.3f|%0.3f|%0.3f|%d|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f\n', HVALUE, PVALUE, ksstat, cv, length(X4), mean(X4), median(X4), prctile(X4, 90), prctile(X4, 99), mean(pd4), median(pd4), icdf(pd4, 0.90), icdf(pd4, 0.99));

pd5 = fitdist(X5, 'Burr');
[HVALUE,PVALUE,ksstat,cv] = kstest(X5, 'CDF', pd5);
fprintf('Burr|%d|%0.3f|%0.3f|%0.3f|%d|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f\n', HVALUE, PVALUE, ksstat, cv, length(X5), mean(X5), median(X5), prctile(X5, 90), prctile(X5, 99), mean(pd5), median(pd5), icdf(pd5, 0.90), icdf(pd5, 0.99));

pd6 = fitdist(X6, 'Burr');
[HVALUE,PVALUE,ksstat,cv] = kstest(X6, 'CDF', pd6);
fprintf('Burr|%d|%0.3f|%0.3f|%0.3f|%d|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f\n', HVALUE, PVALUE, ksstat, cv, length(X6), mean(X6), median(X6), prctile(X6, 90), prctile(X6, 99), mean(pd6), median(pd6), icdf(pd6, 0.90), icdf(pd6, 0.99));

pd7 = fitdist(X7, 'Burr');
[HVALUE,PVALUE,ksstat,cv] = kstest(X7, 'CDF', pd7);
fprintf('Burr|%d|%0.3f|%0.3f|%0.3f|%d|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f\n', HVALUE, PVALUE, ksstat, cv, length(X7), mean(X7), median(X7), prctile(X7, 90), prctile(X7, 99), mean(pd7), median(pd7), icdf(pd7, 0.90), icdf(pd7, 0.99));

pd8 = fitdist(X8, 'Burr');
[HVALUE,PVALUE,ksstat,cv] = kstest(X8, 'CDF', pd8);
fprintf('Burr|%d|%0.3f|%0.3f|%0.3f|%d|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f\n', HVALUE, PVALUE, ksstat, cv, length(X8), mean(X8), median(X8), prctile(X8, 90), prctile(X8, 99), mean(pd8), median(pd8), icdf(pd8, 0.90), icdf(pd8, 0.99));

pd10 = fitdist(X10, 'Burr');
[HVALUE,PVALUE,ksstat,cv] = kstest(X10, 'CDF', pd10);
fprintf('Burr|%d|%0.3f|%0.3f|%0.3f|%d|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f\n', HVALUE, PVALUE, ksstat, cv, length(X10), mean(X10), median(X10), prctile(X10, 90), prctile(X10, 99), mean(pd10), median(pd10), icdf(pd10, 0.90), icdf(pd10, 0.99));

pd11 = fitdist(X11, 'Burr');
[HVALUE,PVALUE,ksstat,cv] = kstest(X11, 'CDF', pd11);
fprintf('Burr|%d|%0.3f|%0.3f|%0.3f|%d|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f\n', HVALUE, PVALUE, ksstat, cv, length(X11), mean(X11), median(X11), prctile(X11, 90), prctile(X11, 99), mean(pd11), median(pd11), icdf(pd11, 0.90), icdf(pd11, 0.99));

pd12 = fitdist(X12, 'Burr');
[HVALUE,PVALUE,ksstat,cv] = kstest(X12, 'CDF', pd12);
fprintf('Burr|%d|%0.3f|%0.3f|%0.3f|%d|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f\n', HVALUE, PVALUE, ksstat, cv, length(X12), mean(X12), median(X12), prctile(X12, 90), prctile(X12, 99), mean(pd12), median(pd12), icdf(pd12, 0.90), icdf(pd12, 0.99));

pd13 = fitdist(X13, 'Burr');
[HVALUE,PVALUE,ksstat,cv] = kstest(X13, 'CDF', pd13);
fprintf('Burr|%d|%0.3f|%0.3f|%0.3f|%d|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f\n', HVALUE, PVALUE, ksstat, cv, length(X13), mean(X13), median(X13), prctile(X13, 90), prctile(X13, 99), mean(pd13), median(pd13), icdf(pd13, 0.90), icdf(pd13, 0.99));

pd14 = fitdist(X14, 'Burr');
[HVALUE,PVALUE,ksstat,cv] = kstest(X14, 'CDF', pd14);
fprintf('Burr|%d|%0.3f|%0.3f|%0.3f|%d|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f\n', HVALUE, PVALUE, ksstat, cv, length(X14), mean(X14), median(X14), prctile(X14, 90), prctile(X14, 99), mean(pd14), median(pd14), icdf(pd14, 0.90), icdf(pd14, 0.99));

pd15 = fitdist(X15, 'Burr');
[HVALUE,PVALUE,ksstat,cv] = kstest(X15, 'CDF', pd15);
fprintf('Burr|%d|%0.3f|%0.3f|%0.3f|%d|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f\n', HVALUE, PVALUE, ksstat, cv, length(X15), mean(X15), median(X15), prctile(X15, 90), prctile(X15, 99), mean(pd15), median(pd15), icdf(pd15, 0.90), icdf(pd15, 0.99));

pd16 = fitdist(X16, 'Burr');
[HVALUE,PVALUE,ksstat,cv] = kstest(X16, 'CDF', pd16);
fprintf('Burr|%d|%0.3f|%0.3f|%0.3f|%d|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f|%0.3f\n', HVALUE, PVALUE, ksstat, cv, length(X16), mean(X16), median(X16), prctile(X16, 90), prctile(X16, 99), mean(pd16), median(pd16), icdf(pd16, 0.90), icdf(pd16, 0.99));

rng(103,'twister');
STT03_1 = random(pd3, noOfSimulations, 1);
fprintf('%0.3f\n', max(STT03_1));

rng(104,'twister');
STT04_1 = random(pd4, noOfSimulations, 1);
fprintf('%0.3f\n', max(STT04_1));

rng(105,'twister');
STT05_1 = random(pd5, noOfSimulations, 1);
fprintf('%0.3f\n', max(STT05_1));

%3 invocations start
rng(106,'twister');
STT06_1 = random(pd6, noOfSimulations, 1);
fprintf('%0.3f\n', max(STT06_1));

rng(206,'twister');
STT06_2 = random(pd6, noOfSimulations, 1);
fprintf('%0.3f\n', max(STT06_2));

rng(306,'twister');
STT06_3 = random(pd6, noOfSimulations, 1);
fprintf('%0.3f\n', max(STT06_3));
%3 invocations end

rng(107,'twister');
STT07_1 = random(pd7, noOfSimulations, 1);
fprintf('%0.3f\n', max(STT07_1));

rng(108,'twister');
STT08_1 = random(pd8, noOfSimulations, 1);
fprintf('%0.3f\n', max(STT08_1));

rng(110,'twister');
STT10_1= random(pd10, noOfSimulations, 1);
fprintf('%0.3f\n', max(STT10_1));

rng(111,'twister');
STT11_1= random(pd11, noOfSimulations, 1);
fprintf('%0.3f\n', max(STT11_1));

rng(112,'twister');
STT12_1= random(pd12, noOfSimulations, 1);
fprintf('%0.3f\n', max(STT12_1));

rng(113,'twister');
STT13_1= random(pd13, noOfSimulations, 1);
fprintf('%0.3f\n', max(STT13_1));

%3 set of 3 start
rng(114,'twister');
STT14_1= random(pd14, noOfSimulations, 1);
fprintf('%0.3f\n', max(STT14_1));

rng(214,'twister');
STT14_2= random(pd14, noOfSimulations, 1);
fprintf('%0.3f\n', max(STT14_2));

rng(314,'twister');
STT14_3= random(pd14, noOfSimulations, 1);
fprintf('%0.3f\n', max(STT14_3));
%3 set of 3 end

%4 set of 4 start
rng(115,'twister');
STT15_1= random(pd15, noOfSimulations, 1);
fprintf('%0.3f\n', max(STT15_1));

rng(215,'twister');
STT15_2= random(pd15, noOfSimulations, 1);
fprintf('%0.3f\n', max(STT15_2));

rng(315,'twister');
STT15_3= random(pd15, noOfSimulations, 1);
fprintf('%0.3f\n', max(STT15_3));

rng(415,'twister');
STT15_4= random(pd15, noOfSimulations, 1);
fprintf('%0.3f\n', max(STT15_4));
%4 set of 4 end

%4 set of 4 start
rng(116,'twister');
STT16_1= random(pd16, noOfSimulations, 1);
fprintf('%0.3f\n', max(STT16_1));

rng(216,'twister');
STT16_2= random(pd16, noOfSimulations, 1);
fprintf('%0.3f\n', max(STT16_2));

rng(316,'twister');
STT16_3= random(pd16, noOfSimulations, 1);
fprintf('%0.3f\n', max(STT16_3));

rng(416,'twister');
STT16_4= random(pd16, noOfSimulations, 1);
fprintf('%0.3f\n', max(STT16_4));
%4 set of 4 end

%STT = STT03_1 + STT04_1 + STT05_1 + (STT06_1 + STT06_2 + STT06_3) + STT07_1 + STT08_1 + STT10_1 + STT11_1 + STT12_1 + STT13_1 + (STT14_1 + STT14_2 + STT14_3) + (STT15_1 + STT15_2 + STT15_3 + STT15_4) + (STT16_1 + STT16_2 + STT16_3 + STT16_4);
STT = STT03_1 + STT04_1 + STT05_1 + (STT06_1 + STT06_2 + STT06_3) + STT07_1 + STT08_1 + STT11_1 + STT12_1 + STT13_1 + (STT14_1 + STT14_2 + STT14_3) + (STT15_1 + STT15_2 + STT15_3 + STT15_4) + (STT16_1 + STT16_2 + STT16_3 + STT16_4);

fname  = sprintf('%s/%s', outpath, outfilename);
if exist(fname, 'file')==2
  delete(fname);
end

fileID = fopen(fname, 'a+');
if (fileID <= 2)
   fprintf('File not found %s\n', fname); 
else
    for n = 1 : length(STT)
        fprintf(fileID, '%f\n', STT(n));
    end
end

fclose(fileID);

end

%example of usage
%inpath = 'C:\raghu\Research 2\Paper 2 - Probability Distributions and Web Services Response Time\Datasets\WS-REAL\WSReal-QoSDataset-16-csv';
%outpath= 'C:\raghu\Research 2\Paper 2 - Probability Distributions and Web Services Response Time\Simulation2\data';
%[STT_BURR] = GenerateSTTUsingBurr(inpath, 10000, outpath, 'stt_burr.txt');