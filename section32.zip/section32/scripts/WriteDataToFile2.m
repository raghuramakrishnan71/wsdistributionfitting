function WriteDataToFile2(path, filename, data, mode)

fname  = sprintf('%s/%s', path, filename);
fileID = fopen(fname, mode);

if (fileID <= 2)
   fprintf('File not found %s\n', fname); 
else
    fprintf(fileID, '%s\n', data);
    fclose(fileID);
end

end