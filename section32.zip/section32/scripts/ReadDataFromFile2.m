function [X] = ReadDataFromFile2(inpath, infilename)

fname  = sprintf('%s/%s', inpath, infilename);
fileID    = fopen(fname, 'r');

if (fileID <= 2)
   fprintf('File not found %s\n', fname); 
else
   %fseek(fileID, 6, 'bof');
 
   formatSpec = '%f';
   X = fscanf(fileID, formatSpec);
   fclose(fileID);   
end

end

%example of usage
%inpath = 'C:\raghu\Research 2\Paper 2 - Probability Distributions and Web Services Response Time\Datasets\WS-REAL\WSReal-QoSDataset-16-csv';
%X3_1= ReadDataFromFile2(inpath, '11.csv');