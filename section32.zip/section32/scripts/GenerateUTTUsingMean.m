function[UTT] = GenerateUTTUsingMean(noOfSimulations, outpath, outfilename)


UTT03_1 = ones(noOfSimulations, 1) * 15;
UTT04_1 = ones(noOfSimulations, 1) * 45;
UTT05_1 = ones(noOfSimulations, 1) * 15;
UTT06_1 = ones(noOfSimulations, 1) * 45;
UTT07_1 = ones(noOfSimulations, 1) * 30;
UTT08_1 = ones(noOfSimulations, 1) * 15;
UTT10_1 = ones(noOfSimulations, 1) * 30;
UTT11_1 = ones(noOfSimulations, 1) * 30;
UTT12_1 = ones(noOfSimulations, 1) * 45;
UTT13_1 = ones(noOfSimulations, 1) * 30;
UTT14_1 = ones(noOfSimulations, 1) * 30;
UTT15_1 = ones(noOfSimulations, 1) * 45;
UTT16_1 = ones(noOfSimulations, 1) * 30;

%UTT = UTT03_1 + UTT04_1 + UTT05_1 + UTT06_1 + UTT07_1 + UTT08_1 + UTT10_1 + UTT11_1 + UTT12_1 + UTT13_1 + UTT14_1 + UTT15_1 + UTT16_1;
UTT = UTT03_1 + UTT04_1 + UTT05_1 + UTT06_1 + UTT07_1 + UTT08_1 + UTT11_1 + UTT12_1 + UTT13_1 + UTT14_1 + UTT15_1 + UTT16_1;


fname  = sprintf('%s/%s', outpath, outfilename);
if exist(fname, 'file')==2
  delete(fname);
end

fileID = fopen(fname, 'a+');
if (fileID <= 2)
   fprintf('File not found %s\n', fname); 
else
    for n = 1 : length(UTT)
        fprintf(fileID, '%f\n', UTT(n));
    end
end

fclose(fileID);

end

%example of usage
%inpath = 'C:\raghu\Research 2\Paper 2 - Probability Distributions and Web Services Response Time\Datasets\WS-REAL\WSReal-QoSDataset-16-csv';
%outpath= 'C:\raghu\Research 2\Paper 2 - Probability Distributions and Web Services Response Time\Simulation2\data';
%[UTT] = GenerateUTTUsingMean(10000, outpath, 'utt_mean.txt');